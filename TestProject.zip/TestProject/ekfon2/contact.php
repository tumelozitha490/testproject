<!DOCTYPE html>
<html lang="en-US">
  <head>
  <title>Ekfon SA </title>
  <link rel="stylesheet" href="libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="libs/style.css">

  <nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">Login</a>
  
  <a class="navbar-brand" href="logout.php">LogOut</a>

  <a class="navbar-brand" href="our.php">Our Service</a>

  <a class="navbar-brand" href="contact.php">Contact Us</a>
      
  <!-- </div> -->
</nav>
  </head>