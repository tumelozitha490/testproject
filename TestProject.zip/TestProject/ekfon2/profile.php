<!DOCTYPE html>
<html lang="en-US">
  <head>
  <title>Ekfon SA </title>
  <link rel="stylesheet" href="libs/css/bootstrap.min.css">
  <link rel="stylesheet" href="libs/style.css">

  <nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php">Login</a>
  
  <a class="navbar-brand" href="logout.php">LogOut</a>

  <a class="navbar-brand" href="our.php">Our Service</a>

  <a class="navbar-brand" href="contact.php">Contact Us</a>
      
  <!-- </div> -->
</nav>
  </head>
  <body background="pic8.jpg">
  <?php
  include 'connection.php';
  session_start();
$id=$_SESSION['id'];
$query=mysqli_query($db,"SELECT * FROM users where user_id='$id'")or die(mysqli_error());
$row=mysqli_fetch_array($query);
  ?>
  <h1>User Profile</h1>
<div class="profile-input-field">
        <h3>Update User Profile</h3>
        <form method="post" action="#" >
          <div class="form-group">
            <label>Fullname</label>
            <input type="text" class="form-control" name="fname" style="width:20em;" placeholder="Enter your Fullname" value="<?php echo $row['full_name']; ?>" required />
          </div>
          <!-- <div class="form-group">
            <label>Gender</label>
            <input type="text" class="form-control" name="gender" style="width:20em;" placeholder="Enter your Gender" required value="<?php echo $row['gender']; ?>" />
          </div> -->
          <div class="form-group">
            <label>Gender</label>
            <select name="gender" id="gender" >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="other">Other(N/A)</option>
            </select>
          </div>
          <!--  -->
          <div class="form-group">
            <label>Surname</label>
            <input type="text" class="form-control" name="surname" style="width:20em;" placeholder="Enter your Surname" required value="<?php echo $row['surname']; ?>" />
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" name="email" style="width:20em;" placeholder="Enter your Email" value="<?php echo $row['email']; ?>">
          </div>
          <div class="form-group">
            <label>Contact Number</label>
            <input type="text" class="form-control" name="contact" style="width:20em;" required placeholder="Enter your Contact" value="<?php echo $row['contact']; ?>"></textarea>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="text" class="form-control" name="password" style="width:20em;" required placeholder="Enter your Password" value="<?php echo $row['password']; ?>"></textarea>
          </div>
          <!--  -->
          <!-- <div class="form-group">
            <label>Age</label>
            <input type="number" class="form-control" name="age" style="width:20em;" placeholder="Enter your Age" value="<?php echo $row['age']; ?>">
          </div>
          <div class="form-group">
            <label>Address</label>
            <input type="text" class="form-control" name="address" style="width:20em;" required placeholder="Enter your Address" value="<?php echo $row['address']; ?>"></textarea>
          </div> -->
          <div class="form-group">
            <input type="submit" name="submit" class="btn btn-primary" style="width:20em; margin:0;"><br><br>
            <center>
             <a href="logout.php">Log out</a>
           </center>
          </div>
        </form>
      </div>
</body>
      </html>
      <?php
      if(isset($_POST['submit'])){
        $fullname = $_POST['fname'];
        $gender = $_POST['gender'];
        $surname = $_POST['surname'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $gender = $_POST['gender'];
        $age = $_POST['age'];
        $address = $_POST['address'];
        $pass = $_POST['pass'];
        
      $query = "UPDATE users SET full_name = '$fullname',
                      gender = '$gender',surname = $surname,email = $email, contact = $contact, age = $age, address = '$address'
                      WHERE user_id = '$id'";
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                    ?>
                     <script type="text/javascript">
            alert("Update Successfull.");
            window.location = "index.php";
        </script>
        <?php
             }               
?>  