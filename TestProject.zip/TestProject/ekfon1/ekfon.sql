-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2021 at 02:50 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.1.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekfon`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `linked` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `fname`, `lname`, `name`, `gender`, `email`, `linked`, `password`, `created_at`) VALUES
(3, 'balajiarun', 'Tumelo Fortune', 'Zitha', 'balaji', 'Male', 'tumelozitha490@gmail.com', 'aaa', '$2y$10$NYucP9aB9KQ/4MVBE9.LnurYf4tqwwB1zM6plbYP5mMmP6tM/sNOC', '2019-04-24 14:11:58'),
(5, 'tumelo@gmail.com', '', '', 'tshilidzi', '', 'tumelozitha@gmail.com', '', '$2y$10$VJ/nZahZMN.eTLihrZd.UOj3Skuys86M5i2fpfEzM.h2tcq1/D4cS', '2021-10-29 03:38:09'),
(6, 'rene', '', '', 'awe', '', 're@awe.com', '', '$2y$10$Cm2VLCrhKzS3sYfV0ZNMO.pgpX6FMqFZqlzi0V4LAx/7H4Hfy/GDC', '2021-10-29 04:02:12'),
(7, 'ree', '', '', 'ree', '', 'r@rene.com', '', '$2y$10$rLI37MQ7gqXczbf1YJ/9SuotNFd7ADLngzGGWzRi/3raE8uI0cyb.', '2021-10-29 04:07:15'),
(8, 'test1 ', '', '', 'test', '', 'tes@tes.com', '', '$2y$10$8So67BHoBlsHZUaUK/ABLeIfFJXdu8qytjTJyrosFwmvbfmhEAM8C', '2021-10-29 04:13:30'),
(9, 'test2', '', '', 'test2', 'Male', 'test@test.com', '', '$2y$10$qFJvzenPEYv4QPvSl3TGeueZDKIPKAiV7g9DgfW.cnXjLoO5uFKOW', '2021-10-29 04:27:14'),
(10, 'awe', '', '', 'rene', '', 'awe@a.com', '', '$2y$10$H8aYu2pKeib1fnrP5hGr3eyx0l.v.vzOeBX5FIyh2dbby41rnI1le', '2021-10-29 04:51:06'),
(11, 'elias', '', '', 'Tumelo Fortune Zitha', 'Male', 'tumelozitha490m@gmail.com', '', '$2y$10$h7A0Ec9J6QC31xRCTq8DBuUfkhLlcTEJkyQeN1MnpaZZMdiYM2gSm', '2021-10-29 05:05:05'),
(12, 'Tumelo3', '', '', 'Tumelo3', '', 'tumelo3@gmail.com', '', '$2y$10$gyFeNhO.lLi1GVFSMDli2.xXqMTJVDuqhCe0QOLUXgi3ZuDgkfbni', '2021-10-29 05:13:54'),
(13, 'test3', '', '', 'test3', 'other', 'test3@test3.com', '11111111', '$2y$10$hG5TA9diQP0St9F//61QNen/aL1e0HSicPluMoKfKwmnPGpwKGHja', '2021-10-29 09:21:22'),
(14, 'test4', '', '', 'test4', 'other', 'te@tes.com', '1212121', '$2y$10$DcNyjDXXysp6T.1AHiaHLu.Bj6lCLYkBIRTxHTIOImIScUmdguA3u', '2021-10-29 14:49:30');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
