<?php echo"<h1>UPDATED SUCCESSFULLY</H1>";
echo"Automatically redirect in 5 seconds";
header( "refresh:5;url=index.php" );
?>