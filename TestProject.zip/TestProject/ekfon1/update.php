<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ekfon";
//connect to database 

$fname=$_POST['first'];
$lname=$_POST['last'];
$gender=$_POST['gender'];
$email=$_POST['email'];
$linked=$_POST['linked'];

$cooky=$_SESSION["favcolor"];// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//update database
$sql = "UPDATE users SET fname='$fname',lname='$lname',email='$email',gender='$gender',linked='$linked' where email='$cooky'";


if ($conn->query($sql) === TRUE) {
    header('Location: confirm.php');
} else {
    echo "0 results";
    echo $fname.$cooky;
}
$conn->close();
?>